```
--8<-- "LICENSE"
```
